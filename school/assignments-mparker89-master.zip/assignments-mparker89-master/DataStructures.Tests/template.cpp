#include "pch.h"
#include "CppUnitTest.h"
#include "crt_check_memory.hpp"
#include "../DataStructures/linked_list.hpp"
using namespace data_structures;

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace data_structures_tests
{
	TEST_CLASS(TemplateTestClass)
	{
	public:

		TEST_METHOD(Test)
		{

		}
		
	};
}
